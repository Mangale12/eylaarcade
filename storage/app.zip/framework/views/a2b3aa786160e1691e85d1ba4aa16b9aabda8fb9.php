<?php $__env->startComponent('mail::message'); ?>




<?php if(isset($details) && !empty($details)): ?>
Hello Admin, This is the 24 hour report.[<?php echo Carbon\Carbon::now().'   ('.config('app.timezone').')' ?>]<br>
<hr>
   
<?php
$details = json_decode($details,'true');
?>
<div>
<?php $__currentLoopData = $details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a => $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<table>
<tr style="">
<td  style="color: #ffff;background: #001fff;font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-left:1px solid #333; border-right:1px solid #333;" width="15%" height="32" align="center">
Game Name
</td>
<td  style="font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-right:1px solid #333;" width="25%" align="center">
<?php echo e($b['game_name']); ?>

</td>
</tr>
<tr style="">
<td  style="color: #ffff;background: #001fff;font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-left:1px solid #333; border-right:1px solid #333;" width="5%" height="32" align="center">
Game Title
</td>
<td  style="font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-right:1px solid #333;" width="25%" align="center">
<?php echo e($b['game_title']); ?>

</td>
</tr>
<tr style="">
<td  style="color: #ffff;background: #001fff;font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-left:1px solid #333; border-right:1px solid #333;" width="5%" height="32" align="center">
Game Balance
</td>
<td  style="font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-right:1px solid #333;" width="25%" align="center">
<?php echo e($b['game_balance']); ?>

</td>
</tr>
<tr style="">
<td  style="color: #ffff;background: #001fff;font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-left:1px solid #333; border-right:1px solid #333;" width="5%" height="32" align="center">
Transactions 
</td>
<td  style="font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-right:1px solid #333;" width="25%" align="center">
<?php echo e($b['total_transactions']); ?>

</td>
</tr>
<tr style="">
<td  style="color: #ffff;background: #001fff;font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-left:1px solid #333; border-right:1px solid #333;" width="5%" height="32" align="center">
Tip 
</td>
<td  style="font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-right:1px solid #333;" width="25%" align="center">
<?php echo e($b['totals']['tip']); ?>

</td>
</tr>
<tr style="">
<td  style="color: #ffff;background: #001fff;font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-left:1px solid #333; border-right:1px solid #333;" width="5%" height="32" align="center">
Load 
</td>
<td  style="font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-right:1px solid #333;" width="25%" align="center">
<?php echo e($b['totals']['load']); ?>

</td>
</tr>
<tr style="">
<td  style="color: #ffff;background: #001fff;font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-left:1px solid #333; border-right:1px solid #333;" width="5%" height="32" align="center">
Redeem 
</td>
<td  style="font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-right:1px solid #333;" width="25%" align="center">
<?php echo e($b['totals']['redeem']); ?>

</td>
</tr>
<tr style="">
<td  style="color: #ffff;background: #001fff;font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-left:1px solid #333; border-right:1px solid #333;" width="5%" height="32" align="center">
Bonus
</td>
<td  style="font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-right:1px solid #333;" width="25%" align="center">
<?php echo e($b['totals']['refer']); ?>

</td>
</tr>
</table>
<br>
<br>
<table  width="800px!important;" border="0" cellspacing="0" cellpadding="0">
<tr style="background: #001fff;color: #ffff;">
<td  style="font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-left:1px solid #333; border-right:1px solid #333;" width="5%" height="32" align="center">
SN
</td>
<td  style="font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-right:1px solid #333;" width="25%" align="center">
User Name
</td>
<td style="font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-right:1px solid #333;" width="25%" align="center">
Fb Name
</td>
<td style="font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-right:1px solid #333;" width="10%" align="center">
Amount
</td>
<td style="font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-right:1px solid #333;" width="5%" align="center">
Type
</td>
<td style="font-family:Verdana, Geneva, sans-serif; font-weight:600; font-size:13px; border-top:1px solid #333; border-bottom:1px solid #333; border-right:1px solid #333;" width="15%" align="center">
Date
</td>
</tr>
<?php $__currentLoopData = $b['histories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<tbody>
<tr>
<td style="padding: 3px;font-family:Verdana, Geneva, sans-serif; font-weight:300; font-size:13px; border-bottom:1px solid #333; border-left:1px solid #333; border-right:1px solid #333;" align="center">
<?php echo e($key+1); ?>

</td>
<td style="padding: 3px;font-family:Verdana, Geneva, sans-serif; font-weight:300; font-size:13px; border-bottom:1px solid #333; border-right:1px solid #333;" align="center">
<?php echo e((!empty($item['form']['full_name']))?$item['form']['full_name']:'Empty'); ?>

</td>
<td style="padding: 3px;font-family:Verdana, Geneva, sans-serif; font-weight:300; font-size:13px; border-bottom:1px solid #333; border-right:1px solid #333;" align="center">
<?php echo e((!empty($item['form']['facebook_name']))?$item['form']['facebook_name']:'Empty'); ?>

</td>
<td style="padding: 3px;font-family:Verdana, Geneva, sans-serif; font-weight:300; font-size:13px; border-bottom:1px solid #333; border-right:1px solid #333;" align="center">
<?php echo e((!empty($item['amount_loaded']))?$item['amount_loaded']:'Empty'); ?>

</td>
<td style="padding: 3px;font-family:Verdana, Geneva, sans-serif; font-weight:300; font-size:13px; border-bottom:1px solid #333; border-right:1px solid #333;" align="center">
<?php echo e((!empty($item['type']))?(($item['type']!='refer')?$item['type']:'bonus'):'Empty'); ?>

</td>
<td style="padding: 3px;font-family:Verdana, Geneva, sans-serif; font-weight:300; font-size:13px; border-bottom:1px solid #333; border-right:1px solid #333;" align="center">
<?php echo e((!empty($item['created_at']))?date('d M-Y',strtotime($item['created_at'])):'Empty'); ?>

</td>
</tr>
</tbody>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
<?php else: ?>
Hello Admin, Nothing to report today.
<?php endif; ?>
<br>
<br>
</div>
Sincerely,
Noor Games.
<?php echo $__env->renderComponent(); ?><?php /**PATH /home/noorgame/public_html/resources/views/mails/report.blade.php ENDPATH**/ ?>