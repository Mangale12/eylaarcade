<?php $__env->startSection('title'); ?>
InActive Players
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php
use Carbon\Carbon;
?>
<style>
    .count-row{
        font-weight: 700;
    }

    .select2{
        width: 100% !important;
    }
    

.overlay {
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background: rgba(0, 0, 0, 0.7);
  transition: opacity 500ms;
  visibility: hidden;
  opacity: 0;
  z-index: 9999;
}
.overlay:target {
  visibility: visible;
  opacity: 1;
}


.popup {
  margin: 70px auto;
  padding: 20px;
  background: #fff;
  border-radius: 5px;
  width: 50% ;
  position: relative;
  transition: all 5s ease-in-out;
 
  

}

.popup h2 {
  margin-top: 0;
  color: #333;
  font-family: Tahoma, Arial, sans-serif;

}
.popup .close {
  position: absolute;
  top: 20px;
  right: 30px;
  transition: all 200ms;
  font-size: 30px;
  font-weight: bold;
  text-decoration: none;
  color: #333;

}
.popup .close:hover {
  color: #FF9800;
}
.popup .content {
  max-height: calc(100vh - 210px);
    overflow-y: auto;
}

@media  screen and (max-width: 700px){
  .box{
    width: 70%;
  }
  .popup{
    width: 70%;
  }
}
</style>
<div class="row justify-content-center">
    <div class="col-12 card">
        <div class="card-body">
            <select class="form-control" name="" id="inactive-players-select">
                <option value="7" <?php echo e((isset($days) && ($days == 7))?'selected':''); ?>>Inactive since 7 days</option>
                <option value="10" <?php echo e((isset($days) && ($days == 10))?'selected':''); ?>>Inactive since 10 days</option>
                <option value="20" <?php echo e((isset($days) && ($days == 20))?'selected':''); ?>>Inactive since 20 days</option>
            </select>
        </div>
        <button  class="btn  btn-primary mb-0" style="background-color:#FF9800;"  > 
            <a href="#popup3" style="color:white;">Send Mail</a></button>
          <div id="popup3" class="overlay" style="z-index: 9;">
            <div class="popup">
                <h2>Send Mail</h2>
                <a class="close" href="#">&times;</a>
                <div class="content ">
                  <form action="<?php echo e(route('send-message-inactive')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <input name="id" type="hidden" value="0" class="form-id">
                      <input name="days" type="hidden" value="<?php echo e($days); ?>">
                  <div class="row">
                      <div class="form-group">
                        <label for="cars">Message</label>
                            <textarea name="message" id="cars" class="form-control" placeholder="write your message"></textarea>              
                          
                      </div>
                      <button type="submit"  class="btn  btn-primary mb-0" style="background-color:#FF9800;"  >Send</button>
                
                  </div>
                </form>
                  </div>
            </div>
          </div>
          <p>
            This Data is of <?php echo e($days); ?> days prior.
        </p>  
    </div>
    <div class="col-md-12 card">
        <div class="card-body">
            
        </div>
        <div class="table-responsive p-4" style="overflow-x:auto;">
            <!--id="datatable-crud"-->
            <table class="table datatable" style="font-size:14px">
                <thead>
                    <tr>
                        <th style="width: 26.328100000000006px!important;">No</th>
                        
                        <th class="cus-width">Full Name</th>
                        <th class="cus-width">Status</th>
                        <th class="cus-width">Note</th>
                        <?php if(Auth::user()->role == 'admin'): ?>
                            <th class="cus-width">Number</th>
                            <th class="cus-width">Email</th>
                        <?php endif; ?>
                            <th class="cus-width">Fb ID</th>
                        
                        <th style="width: 56.3125px!important;text-align:center;!important">State</th>
                        
                        <th class="cus-width" style="width: 56.3125px!important;text-align:center;!important">Months</th>
                        <th class="cus-width">Next-Date</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $count = 1;
                    ?>
                    <?php $__currentLoopData = $forms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $num): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="tr-<?php echo e($num->id); ?>">
                        <td class="count-row"><?php echo e($count++); ?></td>
                        <td class="td-full_name-<?php echo e($num->id); ?>"><?php echo e(ucwords($num->full_name)); ?></td>
                        <td class="td-full_name-<?php echo e($num->id); ?>">
                            <select class="select2 activity-status" data-id="<?php echo e($num->id); ?>">
                                <option>Select Status</option>
                                <?php $__empty_1 = true; $__currentLoopData = $activity_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option class="w-100" value="<?php echo e($status->id); ?>" <?php if($num->status_id == $status->id): ?> selected <?php endif; ?>><?php echo e(ucfirst($status->status)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                                <?php endif; ?>
                            </select>
                        </td>
                        <td class="class td-note-<?php echo e($num->id); ?>" data-id="<?php echo e($num->id); ?>"><?php echo e(($num->note)); ?></td>
                        <?php if(Auth::user()->role == 'admin'): ?>
                            <td class="td-game_id-<?php echo e($num->id); ?>"><?php echo e(($num->number)); ?></td>
                            <td class="td-game_id-<?php echo e($num->id); ?>"><?php echo e(($num->email)); ?></td>
                        <?php endif; ?>
                            <td class="td-facebook_name-<?php echo e($num->id); ?>"><?php echo e(($num->facebook_name)); ?></td>
                        
                        <td class="td-mail-<?php echo e($num->id); ?>" style="width: 56.3125px!important;text-align:center;!important"><?php echo e(ucwords($num->mail)); ?></td>
                        
                        <td class="td-count-<?php echo e($num->id); ?>" style="width: 56.3125px!important;text-align:center;!important"><?php echo e(($num->count)); ?></td>

                        <td class="td-intervals-<?php echo e($num->id); ?>">
                            
                            <?php echo e(date('d M,Y', strtotime($num->intervals))); ?>

                            
                        </td>

                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

    </div>
</div>
</div>
<div style="top: -200px;" class="modal fade bd-example-modal-lg editFormModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header" style="background: <?php echo e(isset($color)?$color->color:'purple'); ?>">
                <h5 class="modal-title" id="exampleModalLabel" style="color: white">Edit User</h5>
                
            </div>
            <div class="modal-body editFormModalBody">
                <div class="appendHere">

                </div>
            </div>
            
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).on('change','#inactive-players-select',function(){
        // console.log($(this).val());
        window.location.replace('/inactive-players/'+$(this).val());
    });
    $(document).on("change", ".activity-status", function (event) {
        event.preventDefault();
        var id = $(this).attr('data-id');
        var status = $(this).val();
        var url  = window.location.origin + '/change-activity-status';
        $.ajax({
            type: "POST",
            url: url,
            data: {
                'id': id,
                'status': status,
            },
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            },
            success: function (response) {
                console.log(response);
                if(response.status == 'ok'){
                    toastr.success('Success', response.message);
                }
            },
            error: function (e) {
                if (e.responseJSON.message) {
                    toastr.error('Error', e.responseJSON.message);
                } else {
                    toastr.error('Error', 'Something went wrong while processing your request.')
                }
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('newLayout.layouts.newLayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/noorgame/public_html/resources/views/newLayout/inactive-player.blade.php ENDPATH**/ ?>