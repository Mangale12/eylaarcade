<div class="row">
    <div class="col-lg-12" style="padding-bottom:20px;">
        <div class="card">
            <div class="card-header pb-0 p-3">
                <h6 class="mb-0">Games</h6>
            </div>
            <div class="card-body p-3">
                <div class="row">
                    <?php if(isset($games) && !empty($games)): ?>
                        <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $query = $_GET;
                                $query['game'] = $game['title'];
                                $query_result = http_build_query($query);
                            ?>
                            <input type="hidden" class="activeGameId" value="<?php echo e(isset($activeGame) ? $activeGame['id'] : '1'); ?>">
                            <div class="col-xl-3 col-sm-3 mb-3 game-card-<?php echo e($game['id']); ?> <?php echo e((isset($activeGame) && $activeGame['id'] == $game['id'])?'active-game-btn':''); ?>">
                                <div class="card game-btn-card">
                                    <div class="card-body p-3">
                                        <div class="row">
                                            <div class="col-12">
                                                <div class="d-flex align-items-center game-card123-<?php echo e($game['title']); ?>" style="justify-content: space-between;">
                                                    <a class="mb-1 game-btn <?php echo e((str_replace(' ','-',$game['title']))); ?>-<?php echo e(($game['id'])); ?>" href="<?php echo e(url('/table?').$query_result); ?>" data-title="<?php echo e(($game['title'])); ?>" data-balance="<?php echo e(($game['balance'])); ?>">
                                                        <div class="icon icon-shape icon-sm me-3 bg-gradient-dark shadow text-center">
                                                            
                                                            <?php if($game['image'] == ''): ?>
                                                            <i class="ni ni-mobile-button text-white opacity-10"></i>
                                                            <?php else: ?>
                                                            <img style="max-width: 100%" src="<?php echo e(asset('/public/uploads/'.$game['image'])); ?>">
                                                            <?php endif; ?>
                                                            
                                                        </div>
                                                    </a>
                                                    <div class="d-flex flex-column">
                                                        <h6 class="mb-1 text-dark text-sm"><?php echo e($game['title']); ?></h6>
                                                        <span class="text-xs game-span-item span-<?php echo e((str_replace(' ','-',$game['title']))); ?>-<?php echo e(($game['id'])); ?> <?php echo e((isset($activeGame) && $activeGame['id'] == $game['id'])?'active-game-btn':''); ?>">$ <?php echo e(($game['balance'])); ?></span>
                                                    </div>
                                                    <div class="d-flex flex-column">
                                                        <a href="#popup8" class="edit-game-table" data-id="<?php echo e($game['id']); ?>"><i class="fa fa-pencil"></i> </a>
                                                        
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                        <div id="popup8" class="overlay">
                            <div class="popup">
                                <h2>Edit Balance</h2>
                                <a class="close" href="#">&times;</a>
                                <div class="content ">
                                    <div class="row" style="padding-top:20px;">
                                        <div class="col-12">
                                            <div class="card mb-4">
                                                <div class="card-body px-0 pt-0 pb-2">
                                                    <form action="<?php echo e(route('gamerUpdateBalance')); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="game_id" class="game_id" value="">
                                                        <div class="form-group">
                                                            <input type="text" class="form-control" name="game_balance" placeholder="Enter Amount">
                                                        </div>
                                                        <div class="form-group">
                                                            <button class="btn btn-success" type="submit">Load</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div >
                            </div >
                        </div >
                        
                    <?php else: ?>
                        No games available
                    <?php endif; ?>
                   
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php /**PATH /home/noorgame/public_html/resources/views/newLayout/components/games.blade.php ENDPATH**/ ?>